from . import ipex
import sys

del sys.modules["rvc.ipex"]
